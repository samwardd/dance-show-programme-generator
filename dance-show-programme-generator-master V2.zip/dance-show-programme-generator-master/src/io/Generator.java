package io;

import model.DSP;
import model.Dance;
import model.DanceGroup;
import model.Performer;
import model.PerformerType;

import java.util.ArrayList;

import exceptions.DanceGroupNotFoundException;

public class Generator {
	
	public Generator() {
	}
	
	/* 
	 * Adding the pupils the file to the Dance groups for the main
	 * Generates the groups at runtime
	 * @param group
	 * */
	public void generateDanceGroups(DSP dsp, Reader reader) {
		ArrayList<ArrayList<String>> groupsList = reader.readFile();

		for(ArrayList<String> readGroup : groupsList) {
			DanceGroup group = new DanceGroup(readGroup.get(0));
			
			for (int i = 1; i < readGroup.size(); i++) {							
				Performer pupil = new Performer(readGroup.get(i), PerformerType.PUPIL);
				group.addPupil(pupil);
			}
			dsp.addGroup(group);
		}
	}
	/* 
	 *  Generates the dances into the lists at runtime and adds
	 * @param guest
	 * */
	public void generateDances(DSP dsp, Reader reader) {
		ArrayList<ArrayList<String>> dancesList = reader.readFile();

		for(ArrayList<String> readDance : dancesList) {
			Dance dance = new Dance(readDance.get(0));
			
			for (int i = 1; i < readDance.size(); i++) {
				DanceGroup searchGroup;
				
				try {
					searchGroup = dsp.getGroup(readDance.get(i));
				} catch (DanceGroupNotFoundException e) {
					searchGroup = null;
				}
				
				if (searchGroup != null) {
					dance.addDanceGroup(searchGroup);
				} else {
					Performer guest = new Performer(readDance.get(i), PerformerType.GUEST);
					dance.addGuestPerformer(guest);
				}
			}
			dsp.addDance(dance);
		}
	}
	/*
	 * Represents a string representation of the dances in order
	 * @return dancesInRunningOrder
	 *  */
	public ArrayList<String> readRunningOrder(Reader reader) {
		ArrayList<String> dancesInRunningOrder = new ArrayList<String>();
		
		try {
			ArrayList<ArrayList<String>> runningOrder = reader.readFile();	
			
			for(ArrayList<String> readDance : runningOrder) {
				dancesInRunningOrder.add(readDance.get(0));
			}
		} catch (NullPointerException e) {
			System.out.println(e.toString());
		}	
				
		return dancesInRunningOrder;		
	}
	
}
