package exceptions;

public class DanceGroupNotFoundException extends Exception {
	
	/**
	 * Provides exception message for the Dance Group not Found 
	 */
	private static final long serialVersionUID = 3594807818083891894L;

	public DanceGroupNotFoundException(String message) {
		super(message);
	}

}
