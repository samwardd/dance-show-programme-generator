package exceptions;

public class PupilNotFoundException extends Exception {
	
	/**
	 * Provides error message for the pupil/dancer not found
	 */
	private static final long serialVersionUID = 2207613508872995836L;

	public PupilNotFoundException(String message) {
		super(message);
	}
}
