package exceptions;

public class DanceNotFoundException extends Exception {

	/**
	 * Provides error message for the Dance not found
	 */
	private static final long serialVersionUID = 8042126307581226070L;

	public DanceNotFoundException(String message) {
		super(message);
	}
}
