package core;

import java.io.FileNotFoundException;

import controller.TUIController;
import io.Generator;
import io.Reader;
import model.DSP;
import view.TUI;


public class DSPG {
	
	public static void main(String[] args) throws FileNotFoundException {		
		DSP dsp = new DSP();
		Generator i = new Generator();
		i.generateDanceGroups(dsp, new Reader("assets/showDanceGroups.csv"));
		i.generateDances(dsp, new Reader("assets/showDance.csv"));
		
		new TUI(new TUIController(dsp));
	}

}
