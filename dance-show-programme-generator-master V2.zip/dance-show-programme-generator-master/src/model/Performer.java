package model;

/* 
 * Initialising and returning the name of the performers and their performance type
 * @return forename
 * @return performerType
 * */
public class Performer implements Comparable<Performer> {
	
	private String forename;
	private PerformerType performerType;
	
	public Performer(String forename, PerformerType performerType) {
		this.forename = forename;
		this.performerType = performerType;
	}
	
	public String getForename() {
		return this.forename;
	}
	
	public PerformerType getPerformerType() {
		return this.performerType;
	}
	// Compares forename to the current pupil forename
	public int compareTo(Performer pupil) {
		return this.getForename().compareTo(pupil.getForename());
	}
}
