package model;
/* pupil = dancers for the dance groups(can mix between dances)
 * guest = guest performers that join any dance
 */
public enum PerformerType {
	PUPIL,
	GUEST,
	;
}
